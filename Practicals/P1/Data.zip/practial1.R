#hello
library(ISLR)
library(tidyverse)
library(haven)
library(readxl)

#all objects
object_1 <- 1:5
object_2 <- 1L:5L
object_3 <- "-123.456"
object_4 <- as.numeric(object_2)
object_5 <- letters[object_1]
object_6 <- as.factor(rep(object_5, 2))
object_7 <- c(1, 2, 3, "4", "5", "6")

object_7 <- as.numeric(object_7)

#list of all objects
objects <- list(object_1, object_2, object_3, object_4, object_5, object_6, 
                object_7)

#dataframe
dat <- data.frame(object_1, object_2,object_5)
dat

ncol(dat)
nrow(dat)


#import data from google playsotre
apps <- read_csv("data/googleplaystore.csv")

head(apps)


students <- read_xlsx("students.xlsx")
head(students)
View(students)
summary(students)
#range of grades from 4.8 to 9.2

unsifficient <- filter(students, grade<5.5)
highgrade_A <- filter(students, grade>8, programme== "A")


studentssorted <- arrange(students, programme, grade) ####??? why is there a minus sign -grade
studentselected <- select(students, student_number, programme)










arrange(students, programme, -grade)
select(students, student_number, programme)


students <- mutate(students, pass = grade > 5.5)
students

students_recoded <- mutate(students, 
                           programme = recode(programme, "A" = "Science", "B" = "Social Science")
)


students_dataset <-
  read_xlsx("students.xlsx") %>% 
  mutate(prog = recode(programme, "A" = "Science", "B" = "Social Science")) %>% 
  filter(grade > 5.5) %>% 
  arrange(programme, -grade) %>% 
  select(student_number, prog, grade)
<<<<<<< HEAD
students_dataset

# Create a data processing pipeline that 
#(a) loads the apps dataset, 
#(b) parses the number of installs as ‘Downloads’ variable using mutate and parse_number(), 
#(c) shows only apps with more than 500 000 000 downloads, 
#(d) orders them by rating (best on top), and
#(e) shows only the relevant columns (you can choose which are relevant, but select at least the Rating and Category variables). Save the result under the name popular_apps.

popular_apps <-
  read_csv("data/googleplaystore.csv")  %>%
  mutate(Downloads = parse_number(Installs)) %>% 
  filter(Downloads > 5e8) %>% # 5e8 is the same as 5 x 10^8
  arrange(-Rating) %>% 
  select(App, Rating, Reviews, Downloads, Category) %>% 
  distinct(App, .keep_all = TRUE)
popular_apps


popular_apps %>% 
  summarise(
    med = median(Rating),
    min = min(Rating), 
    max = max(Rating)
  )


popular_apps %>% 
  summarise(
    med = median(Rating),
    min = min(Rating), 
    max = max(Rating),
    mad = mad(Rating)
  )


popular_apps %>% 
  group_by(Category) %>% 
  summarise(
    med = median(Rating),
    min = min(Rating), 
    max = max(Rating),
    mad = mad(Rating)
  )

popular_apps <-
  read_csv("data/googleplaystore.csv") %>% 
  mutate(Downloads = parse_number(Installs)) %>% 
  filter(Downloads > 5e8) %>% # 5e8 is the same as 5 x 10^8
  arrange(-Rating) %>% 
  select(App, Rating, Reviews, Downloads, Category) %>% 
  distinct(App, .keep_all = TRUE)
popular_apps

popular_apps %>%
  group_by(Category) %>% 
  summarise(
    med = median(Rating),
    min = min(Rating), 
    max = max(Rating),
    mad = mad(Rating)
  )
 #doesnt work????

l